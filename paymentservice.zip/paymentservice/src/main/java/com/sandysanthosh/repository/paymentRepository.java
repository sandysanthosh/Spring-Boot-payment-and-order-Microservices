package com.sandysanthosh.repository;

import com.sandysanthosh.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface paymentRepository extends JpaRepository<Payment,Integer> {

}

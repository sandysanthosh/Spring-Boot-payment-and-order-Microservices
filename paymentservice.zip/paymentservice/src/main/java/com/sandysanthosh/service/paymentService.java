package com.sandysanthosh.service;

import com.sandysanthosh.entity.Payment;
import com.sandysanthosh.repository.paymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class paymentService {

    @Autowired
    private paymentRepository paymentRepository;

    public Payment save (Payment payment)
    {
        return paymentRepository.save(payment);
    }

    public void delete (Payment payment)
    {
         paymentRepository.delete(payment);
    }
}

package com.sandysanthosh.controller;

import com.sandysanthosh.entity.Payment;
import com.sandysanthosh.service.paymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/payment")
public class paymentController {

    @Autowired
    private paymentService paymentService;

    @PostMapping("/addpayment")
    private Payment save(Payment payment)
    {
        return paymentService.save(payment);
    }

}

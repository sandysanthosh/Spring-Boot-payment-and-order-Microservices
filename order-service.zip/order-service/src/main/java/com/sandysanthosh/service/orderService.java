package com.sandysanthosh.service;

import com.sandysanthosh.entity.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sandysanthosh.repository.orderReposiroty;

@Service
public class orderService {

    @Autowired
    private orderReposiroty orderReposiroty;

    public Order save(Order order)
    {
        return orderReposiroty.save(order);
    }


    public void delete(Order order)
    {
        orderReposiroty.delete(order);
    }
}

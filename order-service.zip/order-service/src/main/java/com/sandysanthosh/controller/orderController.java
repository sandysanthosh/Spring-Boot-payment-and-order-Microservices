package com.sandysanthosh.controller;

import com.sandysanthosh.entity.Order;
import org.springframework.web.bind.annotation.*;
import com.sandysanthosh.service.orderService;

@RestController
@RequestMapping("/orders")
public class orderController {

    private orderService orderService;

    @PostMapping("/bookOrders")
    public Order BookOrder(@RequestBody Order order)
    {
        return orderService.save(order);
    }

    @DeleteMapping("/deleteOrders")
    public void DeleteOrder(@RequestBody Order order)
    {
         orderService.delete(order);
    }

}


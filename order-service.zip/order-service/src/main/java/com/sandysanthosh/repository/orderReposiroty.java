package com.sandysanthosh.repository;

import com.sandysanthosh.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface orderReposiroty extends JpaRepository<Order,Integer> {

    void deleteById(Order order);
}
